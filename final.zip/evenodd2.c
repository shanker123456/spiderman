#include<stdio.h>
int main(){
printf("Enter a number: ");
int n;
scanf("%d",&n);
if(n%2==0){
printf("The given number is even number");
}
else{
printf("The given number is odd number");
}
}

